/**Aplicația 7.6: Să se scrie un macro cu număr variabil de argumente, care afișează pe o linie prima oară fișierul și linia curentă,
iar apoi argumentele date.
Exemplu: SRCSHOW(”x=%g, y=%g”,x,y);     va afișa ceva de genul: /home/stud/1.c [21]: x=0.5, y=-7.8
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
/// afiseaza pe o linie fisierul si linia curenta, iar apoi argumentele sale
#if defined(DEBUG)
#define SCRSHOW(...)
printf("fisier: %s ; linie %d", _FILE_, _LINE_);
printf(stderr,_VA_ARGS_)
#else
#define SCRSHOW(...)
#endif // defined
int main()
{
    float x,y;
    printf("x=");
    scanf("%f",&x);
    printf("y=");
    scanf("%f",&y);
    SCRSHOW("x= %g, y=%g",x,y);
    return 0;
}
