/**Aplicația 7.3: Pentru exemplul 2, să se scrie în funcția vmax la început o buclă care afișează conținutul vectorului v.
Toată această buclă va trebui să existe în program doar dacă este definit DEBUG sau _DEBUG.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/// verifica daca este definit DEBUG sau _DEBUG
#if defined(DEBUG) || defined(_DEBUG)
#define  SHOWVECT(...)
fprintf(stderr,_VA_ARGS_)
#else
#define SHOWVECT(...)
#endif // defined
/// functie care returneaza maximul dintr- un vector primit ca parametru
double vmax(double *v,int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        SHOWVECT("i=%d, n=%d, v=%p\n",i,n,v);
        printf("\nv[%d]=",i);
        printf("%lf",v[i]);
    }
    double m=v[0];
    for(i=1; i<n; i++)
    {
        if(m<v[i])
            m=v[i];
    }
    return m;
}
int main()
{
    double *v;
    int i,n;
    printf("n=");
    scanf("%d",&n);
    if((v=(double*)malloc(n*sizeof(double)))==NULL)
    {
        printf("memorie insuficienta");
        exit(EXIT_FAILURE);
    }
    for(i=0; i<n; i++)
    {
        printf("v[%d]=",i);
        scanf("%lf",&v[i]);
    }
    SHOWVECT(v,n,i);
    printf("\nmaximul este: %lf\n",vmax(v,n));
    free(v);
    return 0;
}
