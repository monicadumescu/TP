/**Aplicația 7.4: Pentru exemplul 2, să se scrie o funcție test care primește ca parametri un vector de elemente de tip double,
numărul de elemente din vector și o valoare x de tip double. Funcția va returna 1 dacă x este maximul elementelor din vector, altfel 0.
Folosind această funcție, să se scrie un assert în main care să verifice că vmax returnează într-adevăr maximul elementelor din vector.*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include<assert.h>
/// functie care returneaza maximul dintr- un vector primit ca parametru
double vmax(double *v,int n)
{
    int i;
    double m=v[0];
    for(i=1; i<n; i++)
    {
        if(m<v[i])
            m=v[i];
    }
    return m;
}
/// testaeza daca un numar primit ca parametru este maximul din vector, in caz ca da returneaza 1, altfel returneaza 0
int test(double v[],int n,double x)
{
    int i,M=v[0];
    for(i=1; i<n; i++)
    {
        if(M<v[i])
        {
            M=v[i];
        }
    }
    if(M==x)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main()
{
    double *v;
    int i,n;
    printf("n=");
    scanf("%d",&n);
    if((v=(double*)malloc(n*sizeof(double)))==NULL)
    {
        printf("memorie insuficienta");
        exit(EXIT_FAILURE);
    }
    for(i=0; i<n; i++)
    {
        printf("v[%d]=",i);
        scanf("%lf",&v[i]);
    }
    printf("maximul este: %lf\n",vmax(v,n));
    assert(test(v,n,vmax(v,n))==1);
    free(v);
    return 0;
}
