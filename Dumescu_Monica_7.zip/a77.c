/**Aplicația 7.7: Să se implementeze o funcție sterge(v1,n1,v2,n2), cu v1 și v2 vectori de tip int și n1 și n2
numere întregi care arată câte elemente sunt în v1, respectiv v2. Funcția va șterge din v1 toate elementele care
există în v2 și va returna noua dimensiune a lui v1. Să se scrie un contract pentru această funcție în care să se definească
tot ceea cu nu s-a specificat în descrierea de mai sus, conform viziunii programatorului despre cum ar trebui să se comporte funcția dată.
Pe baza acestui contract, să se introducă în funcție aserțiuni care să verifice respectarea contractului.*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<assert.h>
/**CONTRACT:
-preconditii:
    v1!=NULL
    v2!=NULL
    n1>0
    n2>0
-efecte colaterale: se sterg valorile din v1 care apar si in v2
-invarianti: valorile din v2, cat si n1 si n2 nu se schimba
postonditii: se returneaza noua dimensiune a lui v1
*/
/// functie care sterege elementele din v1 care se afla si in v2 si returneaza noul numar de elemente din v1, cei doi vectori si dimensiuniile acestora
/// sunt trimise ca parametrii
int sterge(int v1[],const int v2[],const int n1,const int n2)
{
    int i=0,j=0,k,n=n1;
    assert(v1!=NULL);
    assert(v2!=NULL);
    assert(n1>0);
    assert(n2>0);
    while(j<n2 && i<n)
    {
        if(v1[i]==v2[j])
        {
            for(k=i; k<n; k++)
            {
                v1[k]=v1[k+1];
            }
            n--;
            i--;
        }
        j++;
        if(j==n2)
        {
            j=0;
            i++;
        }
    }
    return n;
}
/// functia citeste un vector trimis ca parametru, prin variabila n furnizandu-se dimensiunea vectorului, iar prin x indicele vectorului (v1 sau v2)
void citire(int v[],int n,int x)
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("v%d[%i]=",x,i);
        scanf("%d",&v[i]);
    }
}
/// afiseaza un vector primit ca prametru, prin variabila n furnizandu-se dimensiunea acestuia
void afisare(int v[],int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("%d ",v[i]);
    }
    printf("\n");
}
int main()
{
    int v1[100],v2[100],n1,n2,i;
    printf("n1=");
    scanf("%d",&n1);
    citire(v1,n1,1);
    printf("n2=");
    scanf("%d",&n2);
    citire(v2,n2,2);
    printf("v1: ");
    afisare(v1,n1);
    printf("v2: ");
    afisare(v2,n2);
    n1=sterge(v1,v2,n1,n2);
    printf("n1=%d\n",n1);
    printf("v1: ");
    afisare(v1,n1);
    printf("v2: ");
    afisare(v2,n2);
    return 0;
}
