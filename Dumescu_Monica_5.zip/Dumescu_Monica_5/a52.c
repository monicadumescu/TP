/**Aplicatia 5.2: Scrieți un program care copiază conținutul unui fișier sursă într-un fișier destinație.
Numele fișierelor se citesc din linia de comandă. Pentru eficiența copierii, programul va citi
câte un bloc de maxim 4096 de octeți, pe care îl va scrie în destinație.
Exemplu: ./copiere src.dat dst.dat                    -> copiază src.dat în dst.dat
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void open_file(FILE *fis, char name[20])  ///deschide si verifica daca un fisier dat ca parametru a fost deschis cu succes
{
    if((fis=fopen(name,"a+"))==NULL)
    {
        printf("FISIERUL NU A FOST DESCHIS");
        exit(EXIT_FAILURE);
    }
}
int main(int argc,char argv[])
{
    FILE *source_file, *des_file;
    char source_name[20], des_name[20], bloc[4096];
    scanf("%s",source_name);
    scanf("%s",des_name);
    open_file(source_file,source_name);
    open_file(des_file,des_name);
    while(fgets(bloc,4096,source_file))                ///citeste cate un bloc de 4096 caractere
    {
        fwrite(&bloc,sizeof(char),strlen(bloc),des_file);
    }
    fclose(source_file);
    fclose(des_file);
    return 0;
}
