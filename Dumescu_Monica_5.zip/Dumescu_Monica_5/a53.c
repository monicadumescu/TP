/**Aplicația 5.3: Se citesc m și n de la tastatură, iar apoi o matrice a[m][n] cu elemente de tip întreg.
Să se scrie matricea într-un fișier binar, prima oară scriindu-se m și n, iar apoi elementele,
așa cum sunt dispuse ele în memorie. Să se citească matricea din fișier într-o variabilă b și să se afișeze.
*/
#include<stdio.h>
#include<stdlib.h>
void citire(int n,int m,int a[][100])     ///citeste de la tastatura o matrice cu m linii si n coloane date ca parametrii
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]=",i,j);
            scanf("%d",&a[i][j]);
        }
    }
}
void afisare(int n,int m,int a[][100])      ///deschide un fisier si afiseaza in acesta matricea cu m linii si n coloane
{
    int i,j;
    FILE *fis;
    if((fis=fopen("af.dat","w"))==NULL)
    {
        printf("FISIERUL NU A FOST DESCHIS");
        exit(EXIT_FAILURE);
    }
    fwrite(m,sizeof(int),1,fis);
    fwrite(n,sizeof(int),1,fis);
    for(i=0;i<m;i++);
    {
        for(j=0;j<n;j++)
            fwrite(a,sizeof(int),n*m,fis);
    }
    fclose(fis);
}
int main()
{
    int n,m,a[100][100],i,j;
    printf("n=");
    scanf("%d",&n);
    printf("m=");
    scanf("%d",&m);
    citire(n,m,a);
    afisare(n,m,a);
    return 0;
}
