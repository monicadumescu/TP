/**Aplicația 6.5: Să se scrie un macro care generează o structură Punct cu componentele {x,y} de un tip specificat în macro
și totodată o funcție care primește ca parametru o variabilă de tipul Punct și returnează distanța de la punct la origine.
Exemplu: PUNCT(float)                -> va genera structura Punct_float și funcția ”float len_float(Punct_float pt)”*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
/// Macroul genereaza o structura si o functie care returneaza distanta de la punct la orogine
#define PUNCT(tip)  \
    typedef struct \
    { tip x;  \
      tip y; \
    }Punct_##tip; \
    tip len_##tip(Punct_##tip A) \
    { \
        tip b; \
        b=sqrt(A.x*A.x+A.y*A.y); \
        return b; \
    }
int main()
{
    PUNCT(float);
    Punct_float pt;
    printf("x=");
    scanf("%f",&pt.x);
    printf("y=");
    scanf("%f",&pt.y);
    printf("%f",len_float(pt));
    return 0;
}
