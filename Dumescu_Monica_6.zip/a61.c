/**Aplicația 6.1: Să se scrie un macrou care returnează maximul a 3 argumente.*/
#include<stdio.h>
/// Un macrou care returneaza maximul a 3 elemente
#define MAX(a,b,c) (a)>(b) ? ((a)>(c) ? (a):(c)):((b)>(c) ? (b):(c))
int main()
{
    float a,b,c;
    printf("a=");
    scanf("%f",&a);
    printf("b=");
    scanf("%f",&b);
    printf("c=");
    scanf("%f",&c);
    printf("Maximul dintre cele 3 numere este: %f",MAX(a,b,c));
    return 0;
}
