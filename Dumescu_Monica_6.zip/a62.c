/**Aplicația 6.2: Să se scrie un macro care să genereze o funcție de sortare pentru un tip de date dat.
Funcția va primi ca argumente un vector de elemente și dimensiunea sa și va sorta vectorul în ordine crescătoare.
Exemplu: FN_SORTARE(unsigned)        -> va genera o funcție de sortare pentru valori de tip unsigned*/
#include<stdio.h>
#include<stdlib.h>
/// Un macrou care genereaza o functie ce sorteaza elemente unui vector
#define FN_SORTARE(tip) { \
    for(tip i=0;i<n-1;i++){ \
    tip aux;  \
    for(tip j=i; j<n; j++) \
    { \
        if(v[i]>v[j])  \
        { \
            aux=v[i]; \
            v[i]=v[j]; \
            v[j]=aux;  \
        } \
    } \
} \
}
int main()
{
    unsigned n,i,v[100];
    printf("n=");
    scanf("%u",&n);
    for(i=0; i<n; i++)
    {
        printf("v[%u]=",i);
        scanf("%u",&v[i]);
    }
    FN_SORTARE(unsigned)
    for(i=0; i<n; i++)
    {
        printf("%u ",v[i]);
    }
    return 0;
}
