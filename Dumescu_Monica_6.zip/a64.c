/**Aplicația 6.4: Să se scrie un macro care primește ca argumente un text, un placeholder pentru print/scanf, un nume de variabilă și 2 valori,
min și max. Macroul va trebui să ceară de la tastatură o valoare în mod repetat, până când ea se încadrează în intervalul închis dat.
Exemplu: CITIRE(”x=”,g,x,0,100)         -> citește variabila x până când valoarea citită se încadrează în [0,100]*/
#include<stdio.h>
#include<stdlib.h>
/// Macrou care defineste un placeholder pentru scanf
#define cin(c,x) scanf(c,x)
/// Macrpu care genereaza o functie care citeste de la tastatura un numar pana cand acesta se incadreaza in  intervalul dat
#define CITIRE(c,cin,x,a,b) while(x<a || x>b){ \
    printf("%s",c); \
    cin("%d",&x); }
int main()
{
    int x,n,m;
    char c[]= {"x="};
    printf("n=");
    scanf("%d",&n);
    printf("m=");
    scanf("%d",&m);
    x=n-1;
    CITIRE(c,cin,x,n,m);
    return 0;
}
