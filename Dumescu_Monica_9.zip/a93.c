/**Aplicația 9.3: Să se scrie o funcție care primește ca parametri două liste și returnează o listă care reprezintă reuniunea elementelor lor,
fiecare element apărând o singură dată, chiar dacă în listele originare el este duplicat.*/
#include <stdio.h>
#include <stdlib.h>
typedef struct elem
{

    int n;
    struct elem *urm;

} elem;

///aloca memorie pentru un nou element al listei
elem *nou(int n, elem *urm)
{
    elem *e=(elem*)malloc(sizeof(elem));

    if(!e)
    {
        printf("memorie insuficienta");
        exit(EXIT_FAILURE);
    }

    e->n=n;
    e->urm=urm;

    return e;
}

///adauga un elemnt nou la inceputul listei
elem *adaugaInceput(elem *lista, int n)
{
    return nou(n,lista);
}

///afiseaza lista
void afisare(elem *lista)
{
    for(; lista; lista=lista->urm)
    {
        printf("%d ",lista->n);
    }
    putchar('\n');
}

///elibereaza memoria alocata listei
void eliberare(elem *lista)
{
    elem *p;
    while(lista)
    {
        p=lista->urm;
        free(lista);
        lista=p;
    }
}

///verifica daca un element trimis ca parametru apartine listei si returneaza 1 in caz afirmativ
///complexitatea algoritmului: O(n)
int exista(elem *lista, int n)
{
    elem *k = lista;

    while(k != NULL)
    {
        if(k->n == n)
            return 1;

        k=k->urm;
    }

    return 0;
}

///creaza o noua lista carea este reuniunea a doua liste trimise ca parametru
///complexitatea algoritmului: O(n^2)
elem *reuniune(elem *lista1, elem *lista2)
{
    elem *lista = NULL;

    while (lista1 != NULL)
    {
        if (!exista(lista, lista1->n))
        {
            lista = adaugaInceput(lista, lista1->n);
        }
        lista1 = lista1->urm;
    }

    while (lista2 != NULL)
    {
        if (!exista(lista, lista2->n))
        {
            lista = adaugaInceput(lista, lista2->n);
        }
        lista2 = lista2->urm;
    }

    return lista;
}

int main()
{
    elem *lista, *lista1=NULL, *lista2=NULL;

    lista1=adaugaInceput(lista1, 50);
    lista1=adaugaInceput(lista1, -1);
    lista1=adaugaInceput(lista1, 27);
    lista1=adaugaInceput(lista1, -1);
    lista1=adaugaInceput(lista1, -2);

    lista2=adaugaInceput(lista2, 42);
    lista2=adaugaInceput(lista2, 22);
    lista2=adaugaInceput(lista2, 77);
    lista2=adaugaInceput(lista2, 50);
    lista2=adaugaInceput(lista2, -3);

    afisare(lista1);
    afisare(lista2);

    lista=reuniune(lista1, lista2);
    afisare(lista);
    eliberare(lista1);
    eliberare(lista2);
    return 0;
}
