/**Aplicația 9.2: Să se scrie o funcție care primește o listă și returnează lista respectivă cu elementele inversate.
Funcția va acționa doar asupra listei originare, fără a folosi vectori sau alocare de noi elemente.*/
#include<stdio.h>
#include<stdlib.h>
typedef struct elem
{
    int n;
    struct elem *urm;
} elem;

///aloca memorie pentru un nou element al listei
elem *nou(int n,elem *urm)
{
    elem *e=(elem*)malloc(sizeof(elem));
    if(!e)
    {
        printf("Alocarea a esuat");
        exit(EXIT_FAILURE);
    }
    e->n=n;
    e->urm=urm;
    return e;
}

///afiseaza lista
void afisare(elem *lista)
{
    for(; lista; lista=lista->urm)
    {
        printf("%d ",lista->n);
    }
    putchar('\n');
}

///elibereaza memoria alocata pentru lista
void eliberare(elem *lista)
{
    elem *p;
    while(lista)
    {
        p=lista->urm;
        free(lista);
        lista=p;
    }
}

///inverseaza elementele listei
///complexitatea algoritmului: O(n)
void inversare(elem **lista)
{
    elem *p,*q,*r;
    p=q=r=*lista;
    p=p->urm->urm;
    q=q->urm;
    r->urm=NULL;
    q->urm=r;
    while(p!=NULL)
    {
        r=q;
        q=p;
        p=p->urm;
        q->urm=r;
    }
    *lista=q;
}

int main()
{
    elem *lista=nou(5,nou(3,nou(100,nou(10,NULL))));
    afisare(lista);
    inversare(&lista);
    afisare(lista);
    eliberare(lista);
    return 0;
}
