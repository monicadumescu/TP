/**Aplicația 9.1: Să se scrie o funcție care primește două liste și returnează 1 dacă ele sunt identice, altfel 0.*/
#include<stdio.h>
#include<stdlib.h>
typedef struct elem
{
    int n;
    struct elem *urm;
} elem;

///aloca memorie pentru un nou element al listei
elem *nou(int n,elem *urm)
{
    elem *e=(elem*)malloc(sizeof(elem));
    if(!e)
    {
        printf("Alocarea a esuat");
        exit(EXIT_FAILURE);
    }
    e->n=n;
    e->urm=urm;
    return e;
}

///afiseaza lista
void afisare(elem *lista)
{
    for(; lista; lista=lista->urm)
    {
        printf("%d ",lista->n);
    }
    putchar('\n');
}

///compara daca doua liste sunt identice si returneaza 1 in caz afirmativ, altfel returneaza 0
///complexitatea algoritmului: O(n)
int compare(elem *lista1,elem *lista2)
{
    while(lista1!=NULL && lista2!=NULL)
    {
        if(lista1->n!=lista2->n)
        {
            return 0;
        }
        lista1=lista1->urm;
        lista2=lista2->urm;
    }
    return (lista1==NULL && lista2==NULL);
}

///elibereaza memoria ocupata de lista
void eliberare(elem *lista)
{
    elem *p;
    while(lista)
    {
        p=lista->urm;
        free(lista);
        lista=p;
    }
}

int main()
{
    elem *lista1=nou(11,nou(2,nou(58,nou(-3,nou(3,NULL)))));
    elem *lista2=nou(11,nou(2,nou(58,nou(-3,NULL))));
    afisare(lista1);
    afisare(lista2);
    printf("%d\n",compare(lista1,lista2));
    eliberare(lista1);
    eliberare(lista2);
    return 0;
}
