/**Aplicația 10.2: La exemplul 1 să se adauge operația de inserare a unui cuvânt.
Pentru aceasta se cere un cuvânt de inserat și un cuvânt succesor. Dacă succesorul există în propoziție,
cuvântul de inserat va fi inserat înaintea sa. Dacă succesorul nu există în lista, cuvântul de inserat va fi adăugat la sfârșitul listei.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Cuvant
{
    char text[16];
    struct Cuvant *pred;
    struct Cuvant *urm;

} Cuvant;

/// aloca un nou cuvant si ii seteaza campul text
Cuvant *Cuvant_nou(const char *text)
{
    Cuvant *c=(Cuvant*)malloc(sizeof(Cuvant));
    if(!c)
    {
        printf("memorie insuficienta");
        exit(EXIT_FAILURE);
    }
    strcpy(c->text,text);

    return c;
}

typedef struct
{
    Cuvant *prim;
    Cuvant *ultim;

} Propozitie;

///initializare propozitie noua
void Propozitie_init(Propozitie *p)
{
    p->prim = p->ultim = NULL;
}

///adauga un cuvant la sfarsitul propozitiei
void Propozitie_adauga(Propozitie *p, Cuvant *c)
{
    c->pred = p->ultim;

    if(p->ultim)
    {
        p->ultim->urm=c;
    }
    else
    {
        p->prim=c;
    }
    p->ultim=c;
    c->urm=NULL;
}

///cauta un text in propozitie si daca il gaseste returneaza un pointer la cuvantul respectiv
/// daca nu-l gaseste, returneaza NULL
Cuvant *Propozitie_cauta(Propozitie *p, const char *text)
{
    Cuvant *c;

    for(c=p->prim; c; c=c->urm)
    {
        if(!strcmp(c->text,text))
            return c;
    }

    return NULL;
}

///sterge un cuvant din propozitie
void Propozitie_sterge(Propozitie *p, Cuvant *c)
{
    if(c->pred)
    {
        c->pred->urm = c->urm;
    }
    else
    {
        p->prim=c->urm;
    }
    if(c->urm)
    {
        c->urm->pred=c->pred;
    }
    else
    {
        p->ultim=c->pred;
    }
    free(c);
}

///insereaza un cuvant dupa un altul din lista care este citiit de la tastatura,
///daca cuvantul nu exista in lista, adauga noul cuvant la sfarsitul listei
void Propozitie_insert(Propozitie *p, Cuvant *pos, Cuvant *e)
{
    if(pos)
    {
        if(pos->pred)
        {
            e->pred=pos->pred;
            pos->pred->urm=e;
        }
        else
        {
            p->prim=e;
            e->pred=NULL;
        }
        pos->pred=e;
        e->urm=pos;
    }
    else
    {
        Propozitie_adauga(p, e);
    }
}

///elibereaza cuvintele din memorie si reinitializeaza propozitia ca fiind vida
void Propozitie_elibereaza(Propozitie *p)
{
    Cuvant *c, *urm;

    for(c=p->prim; c; c=urm)
    {
        urm=c->urm;
        free(c);
    }
    Propozitie_init(p);
}

int main()
{
    Propozitie p;
    int op;
    char text[16], text2[16];
    Cuvant *c;

    Propozitie_init(&p);

    do
    {

        printf("1 - propozitie noua\n");
        printf("2 - afisare\n");
        printf("3 - stergere cuvant\n");
        printf("4 - inserare cuvant\n");
        printf("5 - iesire\n");
        printf("optiune: ");
        scanf("%d",&op);

        switch(op)
        {
        case 1:
            Propozitie_elibereaza(&p);
            for(;;)
            {
                scanf("%s",text);

                if(!strcmp(text,"."))
                    break;

                Cuvant *c = Cuvant_nou(text);
                Propozitie_adauga(&p,c);
            }
            break;

        case 2:
            for(c=p.prim; c; c=c->urm)
                printf("%s ", c->text);
            printf(".\n");
            break;

        case 3:
            printf("cuvant de sters:");
            scanf("%s",text);
            c=Propozitie_cauta(&p, text);
            if(c)
            {
                Propozitie_sterge(&p, c);
            }
            else
            {
                printf("cuvantul \"%s\" nu se gaseste in propozitie\n", text);
            }
            break;

        case 4:
            printf("cuvant de inserat:");
            scanf("%s",text);
            printf("succesorul sau:");
            scanf("%s",text2);

            Cuvant *e = Cuvant_nou(text);
            Cuvant *pos = Propozitie_cauta(&p, text2);

            Propozitie_insert(&p, pos, e);

            break;

        case 5:
            break;

        default:
            printf("optiune invalida");
        }
    }
    while(op != 5);

    return 0;
}
