/**
Se citesc de la tastatură maxim 100 numere reale, până la întâlnirea numărului 0.
Să se sorteze aceste numere și să se scrie într-un fișier, toate numerele fiind pe o singură linie, separate prin | (bară verticală).
*/
#include<stdio.h>
#include<stdlib.h>
void ordonare(int n,int v[])
{
    int i,j,aux;
    for(i=0; i<n-1; i++)
    {
        for(j=i; j<n; j++)
        {
            if(v[i]>v[j])
            {
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    }
}
void afisare(int n,int v[])
{
    int i;
    FILE *fis;
    if((fis=fopen("out.txt","w"))==NULL)
    {
        printf("Fisierul nu a fost deschis");
        exit(EXIT_FAILURE);
    }
    for(i=0; i<n; i++)
    {
        fprintf(fis,"%d | ",v[i]);
    }
    fclose(fis);
}
int main()
{
    int n=0,v[100],i=0;
    printf("x=");
    scanf("%d",&v[0]);
    while(v[i]!=0)
    {
        i++;
        printf("x=");
        scanf("%d",&v[i]);
    }
    n=i;
    ordonare(n,v);
    afisare(n,v);
    return 0;
}
