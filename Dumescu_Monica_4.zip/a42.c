/**Se citesc m și n de la tastatură, iar apoi o matrice a[m][n].
Matricea va fi alocată dinamic. Să scrie într-un fișier atât matricea originală cât și transpusa ei, separate  printr-o linie goală.
*/
#include<stdio.h>
#include<stdlib.h>
void citire(int n,int m,int *a)
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]=",i,j);
            scanf("%d",&a[i*n+j]);
        }
    }
}
void afisare(int n,int m,int *a)
{
    int i,j;
    FILE *fis;
    if((fis=fopen("out.txt","w"))==NULL)
    {
        printf("Fisierul nu a fost deschis");
        exit(EXIT_FAILURE);
    }
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            fprintf(fis,"%d ",a[i*n+j]);
        fprintf(fis,"\n");
    }
}
void transpusa(int n,int m,int *a)
{
    int i,j;
    FILE *fis;
    for(j=0; j<n; j++)
    {
        for(i=0; i<m; i++)
        {
            fprintf(fis,"%d ",a[i*n+j]);
        }
        fprintf(fis,"\n");
    }
    fclose(fis);
}
int main()
{
    int n,m,*a,i;
    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);
    if((a=(int*)malloc(m*n*sizeof(int)))==NULL)
    {
        printf("Alocarea a esuat");
        exit(EXIT_FAILURE);
    }
    citire(n,m,a);
    afisare(n,m,a);
    transpusa(n,m,a);
    free(a);
    return 0;
}
