/**
Folosind câmpuri pe biți, definiţi o structură pentru memorarea următoarelor informaţii despre animale:
numărul de picioare: număr întreg, minim 0 (ex. şarpe), maxim 1000 (ex. miriapod)
greutatea în kg: număr real
periculos pentru om: da/nu
abrevierea ştiinţifică a speciei: şir de maxim 8 caractere
vârsta maximă în ani: număr întreg, minim 0, maxim 2000
Unde este posibil, codificaţi informaţiile prin numere întregi de dimensiune cât mai mică,
spre exemplu “da”=1, “nu”=0. Definiţi structura în aşa fel încât să ocupe spaţiul minim de memorie posibil.
Afişaţi spaţiul de memorie ocupat, folosind operatorul sizeof. Folosind structura definită,
citiţi de la tastatură informaţii despre un animal, iar pe urmă afişaţi-le pe ecran.
*/
#include<stdlib.h>
#include<stdio.h>
typedef struct
{
    unsigned int pericol:1;
    char specie[8];
    unsigned int picioare,varstam;
    float greutate;
} Animale;
void citire(Animale *a)
{
    int aux;
    printf("Specie: ");
    scanf("%s",a->specie);
    printf("Numar picioare: ");
    scanf("%u",&a->picioare);
    printf("Varsta maxima: ");
    scanf("%u",&a->varstam);
    printf("Periculos pentru om (nu-0, da-1)");
    scanf("%u",&aux);
    a->pericol=aux;
    printf("Greutate: ");
    scanf("%f",&a->greutate);
}
void afisare(Animale *a)
{
    printf("Specie: %s\n",a->specie);
    printf("Numar picioare: %u\n",a->picioare);
    printf("Varsta maxima: %u\n",a->varstam);
    printf("Periculos pentru om (nu-0, da-1): %u\n",a->pericol);
    printf("Greutate: %f\n",a->greutate);
}
int main()
{
    Animale a;
    printf("%g\n",sizeof(Animale));
    citire(&a);
    afisare(&a);
    return 0;
}
