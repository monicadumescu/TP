/**
Folosind struct și union, definiți o structură de date care să poată memora următoarele informații despre viețuitoare:
tipul (poate fi: mamifer, insectă, pește, pasăre)
durata medie de viață în ani
dacă e mamifer: perioada de gestație, numărul mediu de pui pe care îi naște
dacă e insectă: numărul de picioare, dacă poate să zboare sau nu, dacă este periculoasă sau nu pentru om
dacă e pește:  tipul de apă: sărată/dulce, adâncimea maximă la care se poate întâlni, viteza maximă de înot
dacă e pasăre: anvergura aripilor, altitudinea maximă de zbor, viteza maximă de zbor
Definiți structura în așa fel încât memoria consumată să fie minimă. Citiți și afișați informațiile despre o viețuitoare.
*/
#include<stdlib.h>
#include<stdio.h>
typedef enum {mamifer,insecta,peste,pasare} TipAnimal;
typedef enum {zboara,nuzboara} zbor;
typedef enum {periculos,nepericulos} pericol;
typedef enum {sarata,dulce} tipapa;
typedef struct
{
    int TipAnimal;
    union
    {
        struct
        {
            int pergest,nrpui;
        } mamifer;
        struct
        {
            int nrpic,zbor,pericol;
        } insecta;
        struct
        {
            int tipapa;
            float adancime,viteza;
        } peste;
        struct
        {
            float anvaripi,altitudine,viteza;
        } pasare;
    } proprietati;
} Animal;
void citire(Animal *v)
{
    printf("tip animal (mamifer-0, insecta-1, peste-2, pasare-3):");
    scanf("%d",&v->TipAnimal);
    switch(v->TipAnimal)
    {
    case mamifer:
        printf("\nperioada gestatie ");
        scanf("%d",&v->proprietati.mamifer.pergest);
        printf("numar pui ");
        scanf("%d",&v->proprietati.mamifer.nrpui);
        break;
    case insecta:
        printf("numar picioare ");
        scanf("%d",&v->proprietati.insecta.nrpic);
        printf("zboara? (zboara-0, nu zboara-1) ");
        scanf("%d",&v->proprietati.insecta.zbor);
        printf("periculoasa pentru om? (periculos-0, nepericulos-1) ");
        scanf("%d",&v->proprietati.insecta.pericol);
        break;
    case peste:
        printf("tip apa (sarata-0, dulce-1) ");
        scanf("%d",&v->proprietati.peste.tipapa);
        printf("adancime ");
        scanf("%f",&v->proprietati.peste.adancime);
        printf("viteza ");
        scanf("%f",&v->proprietati.peste.viteza);
        break;
    case pasare:
        printf("anvergura aripi ");
        scanf("%f",&v->proprietati.pasare.anvaripi);
        printf("altitudine maxima ");
        scanf("%f",&v->proprietati.pasare.altitudine);
        printf("viteza zbor ");
        scanf("%f",&v->proprietati.pasare.viteza);
        break;
    default:
        printf("\ntip necunoscut");
    }
}
void afisare(Animal *v)
{
    printf("tip animal (mamifer-0, insecta-1, peste-2, pasare-3): %d",v->TipAnimal);
    switch(v->TipAnimal)
    {
    case mamifer:
        printf("\nperioada gestatie %d",v->proprietati.mamifer.pergest);
        printf("numar pui %d",v->proprietati.mamifer.nrpui);
        break;
    case insecta:
        printf("numar picioare %d",v->proprietati.insecta.nrpic);
        printf("zboara? (zboara-0, nu zboara-1) %d",v->proprietati.insecta.zbor);
        printf("periculoasa pentru om? (periculos-0, nepericulos-1) %d",v->proprietati.insecta.pericol);
        break;
    case peste:
        printf("tip apa (sarata-0, dulce-1) %d",v->proprietati.peste.tipapa);
        printf("adancime %f",v->proprietati.peste.adancime);
        printf("viteza %f",v->proprietati.peste.viteza);
        break;
    case pasare:
        printf("anvergura aripi %f",v->proprietati.pasare.anvaripi);
        printf("altitudine maxima %f",v->proprietati.pasare.altitudine);
        printf("viteza zbor %f",v->proprietati.pasare.viteza);
        break;
    default:
        printf("\ntip necunoscut");
    }
}
int main()
{
    Animal a;
    citire(&a);
    afisare(&a);
    return 0;
}
