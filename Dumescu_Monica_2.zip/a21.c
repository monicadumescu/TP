/**
Pentru structura Vehicul de mai sus, să se implementeze funcțiile de introducere de la tastatură și de afișare.
*/
#include<stdio.h>
#include<stdlib.h>
typedef enum {TMBenzina=0, TMMotorina=1, TMElectric=2}TipMotor;
typedef enum {TVPersoane=0, TVMarfa=1, TVSpecial=2}TipVehicul;
const char *numeTM[]= {"benzina", "motorina", "electric"};
typedef struct
{
    TipMotor tm;
    char marca[20];
    TipVehicul tv;
    union
    {
        struct
        {
            int nrLocuri;
            int nrAirbaguri;
        } p;
        struct
        {
            double capacitate;
            char frigorific;
        } m;
        char special[20];
    } specific;
} Vehicul;
void citire(Vehicul *v)
{
    printf("tip motor (0-benzina, 1-motorina, 2-electric): ");
    scanf("%d",&v->tm);
    printf("\nmarca si tip:");
    scanf("%s",v->marca);
    printf("tip vehicul (0-pers, 1-marfa, 2-special):");
    scanf("%d",&v->tv);
    switch(v->tv)
    {
    case TVPersoane:
        scanf("%d",v->specific.p.nrLocuri);
        scanf("%d",v->specific.p.nrAirbaguri);
        break;
    case TVMarfa:
        scanf("%lf",v->specific.m.capacitate);
        scanf("hhd",v->specific.m.frigorific);
    break;
    case TVSpecial:
        fgets(v->specific.special,20,stdin);
        break;
    default:
        printf("tip invalid\n");
    }
}
void afisare(Vehicul *v)
{
    printf("tip motor: %s\n",numeTM[v->tm]);
    printf("marca si tip: %s  %d\n",v->marca,v->tv);
    switch(v->tv)
    {
    case TVPersoane:
        printf("numar locuri: %d",v->specific.p.nrLocuri);
        printf("numar airbaguri: %d",v->specific.p.nrAirbaguri);
        break;
    case TVMarfa:
        printf("capacitate: %lf",v->specific.m.capacitate);
        printf("frigorific: hhd",v->specific.m.frigorific);
        break;
    case TVSpecial:
        printf("special: %s",v->specific.special);
        break;
    default:
        printf("tip invalid\n");
    }
}
int main()
{
    Vehicul v;
    citire(&v);
    afisare(&v);
    return 0;
}
