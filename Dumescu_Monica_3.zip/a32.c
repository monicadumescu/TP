/**Să se implementeze o funcție care primește ca parametri un vector de întregi,
numărul elementelor din vector transmis prin adresă și un predicat care testează
dacă un întreg îndeplinește o anumită condiție. Funcția va sterge din vector toate
elementele care nu îndeplinesc condiția dată și va actualiza numărul elementelor cu
numărul de elemente rămas în vector. Să se testeze funcția cu un predicat care testează
dacă un număr este negativ și să se afișeze vectorul rezultat.*/
#include<stdio.h>
#include<stdlib.h>
void citire(int n,int v[])
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("v[%d]=",i);
        scanf("%d",&v[i]);
    }
}
void afisare(int n,int v[])
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("%d ",v[i]);
    }
}
int cond(const void *e1)
{
    const int *p1=(const int*)e1;
    if(p1>0)
        return 0;
    return 1;
}
void verificare(int *n,int v[],int(*cond)(int))
{
    int i,j;
    for(i=0; i<(*n); i++)
    {
        if(!cond(v+i))
        {
            for(j=i; j<(*n); j++)
            {
                v[j]=v[j+1];
            }
            (*n)--;
        }
    }
}
int main()
{
    int n,v[100];
    printf("n=");
    scanf("%d",&n);
    citire(n,v);
    verificare(&n,v,cond);
    afisare(n,v);
    return 0;
}
