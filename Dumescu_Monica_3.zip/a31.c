/**Se cere un număr n și apoi un vector de n rezultate ale studenților la un examen.
Fiecare rezultat este definit prin (nume,nota). Se cere să se sorteze folosind qsort vectorul în ordinea notelor,
notele cele mai mari fiind primele. Dacă două note sunt identice, rezultatele respective se vor sorta în ordinea alfabetică a numelor.*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
typedef struct
{
    char nume[21];
    float nota;
} Rezultat;
int compara(const void *e1,const void *e2)
{
    const Rezultat *p1=(const Rezultat*)e1;
    const Rezultat *p2=(const Rezultat*)e2;
    if(p1->nota>p2->nota)
        return -1;
    if(p1->nota<p2->nota)
        return 1;
    return 0;
}
void citire(int n,Rezultat studenti [])
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("nume: ");
        scanf("%s",studenti[i].nume);
        printf("nota: ");
        scanf("%f",&studenti[i].nota);
    }
}
void afisare(int n,Rezultat studenti[])
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("%s: %f\n",studenti[i].nume,studenti[i].nota);
    }
}
int main()
{
    Rezultat studenti[10];
    int n;
    printf("n=");
    scanf("%d",&n);
    citire(n,studenti);
    qsort(studenti,n,sizeof(Rezultat),compara);
    afisare(n,studenti);
    return 0;
}
