/**Aplicația 8.4: Să se scrie o funcție crescator(int n,char tip,...) care primește un număr n de valori și returnează 1
dacă ele sunt în ordine strict crescătoare, altfel 0. Caracterul tip indică tipul valorilor și poate fi ‘d’ - int, ‘f’ - double.
Exemplu: printf(“%d”,crescator(3,’d’,-1,7,9));*/
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
///verifica daca n valori primite ca parametrii sunt n ordine crescatoare si returneaza 1 in caza afirmativ
int crescator(int n, char tip,...)
{
    va_list va;
    va_start(va,n);
    int i,j;
    for(i=0; i<n; i++)
    {
        double e= va_arg(va,double);
        switch(tip)
        {
        case 'f':
            for(j=i+1; j<n; j++)
            {
                if(e>va_arg(va,double))
                {
                    return 0;
                }
            }
            return 1;
            break;
        case 'd':
            for(j=i+1; j<n; j++)
            {
                if(e>va_arg(va,int))
                {
                    return 0;
                }
            }
            return 1;
            break;
        }
    }
    va_end(va);
}
int main()
{
    printf("%d\n",crescator(3,'d',-1.0,7.0,9.0));
    printf("%d\n",crescator(3,'d',1.5,0.0,87.0));
    printf("%d\n",crescator(3,'f',-1.67,4.0,5.5));
    printf("%d",crescator(3,'f',3.14,2.5,10.0));
    return 0;
}
