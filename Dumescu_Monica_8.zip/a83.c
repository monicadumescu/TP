/**Aplicația 8.3: Să se scrie o funcție absN(int n,...) care primește un număr n de adrese de tip float și setează
la fiecare dintre aceste adrese valoarea absolută de la acea locație.
Exemplu: absN(2,&x,&y);        // echivalent cu x=fabs(x); y=fabs(y);*/
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
#include<math.h>
/// functia primeste n adreses de tip float si seteaza la fiecare dintre aceste adrese valoarea absoluta de la acea locatie
void absN(int n,...)
{
    float *e;
    va_list va;
    va_start(va,n);
    while(n--)
    {
        e=va_arg(va,float*);
        *e=fabs(*e);
    }
    va_end(va);
}
int main()
{
    float a=-3,b=5.77,c=-3.3,d=-2.7,e;
    absN(2,&a,&b,&e);
    printf("%f %f %f\n",a,b,e);
    absN(3,&a,&c,&d);
    printf("%f %f %f",a,c,d);
    return 0;
}
