/**Aplicația 8.2: Să se scrie o funcție float *allocVec(int n,...) care primește pe prima poziție un număr de elemente iar apoi n elemente reale.
Funcția va aloca dinamic un vector de tip float în care va depune toate elementele.
Exemplu: allocVec(3,7.2,-1,0)        => {7.2, -1, 0}*/
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
///functia aloca dinamic un vector de n elemente primite ca parametrii
float *allocVec(int n,...)
{
    va_list va;
    va_start(va,n);
    float *m;
    int i;
    if((m=(float *)malloc(n*sizeof(float)))==NULL)
    {
        printf("Memorie insuficienta");
        exit(EXIT_FAILURE);
    }
    for(i=0; i<n; i++)
    {
        double a=va_arg(va,double);
        m[i]=a;
    }
    va_end(va);
    for(i=0; i<n; i++)
    {
        printf("%f  ",m[i]);
    }
    printf("\n");
    return va;
}
int main()
{
    allocVec(3,7.2,-1.0,0);
    allocVec(4,3.3,-2.0,9.0,87.0);
    return 0;
}
