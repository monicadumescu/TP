// main.c - meniu utilizator si comportament global
/**Aplicația 11.1: La exemplul din laborator să se adauge opțiunea de meniu “listeaza după salariu”,
care va lista persoanele în ordinea crescătoare a salariului.
Aplicația 11.2: La exemplul din laborator să se adauge opțiunea de meniu “modifică”.
Pentru aceasta se cere numele persoanei a cărei înregistrare va fi modificată, iar apoi se vor cere noul nume și salariu.
Baza de date trebuie să rămână sortată alfabetic, chiar dacă noul nume diferă  de cel anterior.
Aplicația 11.3: La exemplul din laborator să se adauge câmpul ”sex” de tip char la structura Persoana, cu două valori: ‘m’ - masculin, ‘f’ - feminin.
Se vor modifica funcțiile de adăugare, salvare, încărcare și listare pentru a opera și cu acest câmp.*/
#include "util.h"
#include "bd.h"

#include <stdio.h>

int main()
{
    char nume[MAX_NUME],sex;
    float salariu;
    Persoana *p;

    incarca();
    for(;;)
    {
        printf("1. adaugare\n");
        printf("2. stergere\n");
        printf("3. listare\n");
        printf("4. Listeaza dupa salariu\n");
        printf("5. Modifica\n");
        printf("6. iesire\n");
        int op;
        printf("optiune: ");
        scanf("%d",&op);
        switch(op)
        {
        case 1:
            getchar();
            citesteText("nume",nume,MAX_NUME);
            citesteSex("sexul (f sau m)",&sex);
            salariu=citesteFloat("salariu");
            adauga(nume,sex,salariu);
            break;
        case 2:
            getchar();
            citesteText("nume",nume,MAX_NUME);
            if(sterge(nume))
            {
                printf("%s a fost sters din baza de date\n",nume);
            }
            else
            {
                printf("%s nu exista in baza de date\n",nume);
            }
            break;
        case 3:
            for(p=bd; p; p=p->urm)
            {
                printf("%s\t%c\t%g\n",p->nume,p->sex,p->salariu);
            }
            break;
        case 4:
            asc();
            printf("\n");
            for(p=o; p; p=p->urm)
            {
                printf("%s\t%c\t%g\n",p->nume,p->sex,p->salariu);
            }
            break;
        case 5:
            getchar();
            citesteText("nume ",nume,MAX_NUME);
            sterge(nume);
            citesteText("nume",nume,MAX_NUME);
            citesteSex("sex ",sex);
            salariu=citesteFloat("salariu ");
            adauga(nume,sex,salariu);
            break;
        case 6:
            salveaza();
            elibereaza();
            return 0;
        default:
            printf("optiune invalida\n");
        }
    }
}

