// fis.c - functii de salvare si incarcare din fisier a bazei de date
#include "bd.h"
#include "util.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
///salveaza datele pe disc
void salveaza()
{
    FILE *fis=fopen("bd.txt","wb");
    if(!fis)
        err("nu se poate crea bd.txt");
    Persoana *p;
    for(p=bd; p; p=p->urm)
    {
        fprintf(fis,"%s;%c;%g\n",p->nume,p->sex,p->salariu);
    }
    fclose(fis);
}

///incarca baza de data pe disc
void incarca()
{
    elibereaza();
    FILE *fis=fopen("bd.txt","rb");
    if(!fis)
        return;
    char linie[MAX_NUME+32];
    while(fgets(linie,MAX_NUME+32,fis))
    {
        char *sep=strchr(linie,';');
        if(!sep)
            continue;
        int nNume=sep-linie;
        if(nNume>=MAX_NUME)
            nNume=MAX_NUME-1;
        char nume[MAX_NUME];
        memcpy(nume,linie,nNume);
        nume[nNume]='\0';
        float salariu=(float)atof(sep+1);
        char sex;
        adauga(nume,sex,salariu);
    }
    fclose(fis);
}

