// bd.c - functii de operare cu baza de date
#include "bd.h"
#include "util.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

Persoana *bd,*o;

/// creaza un nou element de tip Persoana
static Persoana *nou(const char *nume,char sex,float salariu, Persoana *urm)
{
    Persoana *p=(Persoana*)malloc(sizeof(Persoana));
    if(!p)
        err("memorie insuficienta");
    strcpy(p->nume,nume);
    p->salariu=salariu;
    p->sex=sex;
    p->urm=urm;
    return p;
}
///adauga o noua persoana in baza de date
void adauga(const char *nume,char sex,float salariu)
{
    Persoana *pred=NULL;
    Persoana *crt;

    for(crt=bd; crt; pred=crt,crt=crt->urm)
    {
        if(strcmp(crt->nume,nume)>=0)
            break;
    }
    if(pred)
    {
        pred->urm=nou(nume,sex,salariu,crt);
    }
    else
    {
        bd=nou(nume,sex,salariu,crt);
    }
}

///sterge o persoana in din baza de date
int sterge(const char *nume)
{
    Persoana *pred=NULL;
    Persoana *crt;
    for(crt=bd; crt; pred=crt,crt=crt->urm)
    {
        if(!strcmp(crt->nume,nume))
        {
            if(pred)
            {
                pred->urm=crt->urm;
            }
            else
            {
                bd=crt->urm;
            }
            free(crt);
            return 1;
        }
    }
    return 0;
}

///elibereaza memoria alocata pentru persoanele din baza de date
void elibereaza()
{
    Persoana *crt,*urm;
    for(crt=bd; crt; crt=urm)
    {
        urm=crt->urm;
        free(crt);
    }
    bd=NULL;
}

///adauga la inceputul sau la sfarsitul listei
void adauga_s(const char *nume,const char sex,float salariu)
{
    Persoana *pred=NULL;
    Persoana *crt;
    for(crt=o; crt; crt=crt->urm)
    {
        if(crt->salariu>salariu)
        {
            break;
        }
    }
    if(pred)
    {
        pred->urm=nou(nume,sex,salariu,crt);
    }
    else
    {
        o=nou(nume,sex,salariu,crt);
    }
}

///ordoneaza elementele i ordine crescatoare in functie de salariu
Persoana *asc()
{
    Persoana *o=NULL;
    Persoana *crt;
    o=nou(bd->nume,bd->sex,bd->salariu,NULL);
    for(crt=bd; crt; crt=crt->urm)
    {
        adauga_s(crt->nume,crt->sex,crt->salariu);
    }
    return o;
}
